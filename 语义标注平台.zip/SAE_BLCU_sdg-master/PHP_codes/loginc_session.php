<?php
require("config2.php");
$_SESSION['users']= $_POST['username'];
echo "yes";
?>
